import java.util.ArrayList;

public class Square {

    private Player owner = null;
    private int squareNo;
    private ArrayList<Object> properties = new  ArrayList<>();

    public Square(){
    }
    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

    public int getSquareNo() {
        return squareNo;
    }

    public void setSquareNo(int squareNo) {
        this.squareNo = squareNo;
    }

    public ArrayList<Object> getProperties() {
        return properties;
    }

    public void setProperties(ArrayList<Object> properties) {
        this.properties = properties;
    }
}
