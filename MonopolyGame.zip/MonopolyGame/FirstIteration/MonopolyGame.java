import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class MonopolyGame {

    private BankAccount bank = new BankAccount();
    private Dice dice = new Dice();
    private ArrayList<Player> remainingPlayers = new ArrayList<>();
    private ArrayList<Player> players = new ArrayList<>();
    Board board = new Board();
    GameProperties props =new GameProperties() ;
    int counter = props.getCycleCount();

    public MonopolyGame() throws IOException {
    }

    public void play() throws IOException {

        createPlayers();
        determinePlayingOrder();
        while(controlFinish()) {//till the game ends...

            for (int j = 0; j < remainingPlayers.size(); j++) { //bir cycle
                System.out.println("-----------------------------------------------------------------------------------------");
                System.out.println("Cycle counter is : "+ (props.getCycleCount()-counter +1));
                System.out.println("Turn is player :" + remainingPlayers.get(j).getName());
                System.out.println("Its turn counter is : " +(remainingPlayers.get(j).getTurnCounter() + 1));
                System.out.println("Its current location is : "+ remainingPlayers.get(j).getCurrentSquare().getSquareNo());
                System.out.println("Type of squares : " + remainingPlayers.get(j).getCurrentSquare().getClass());
                System.out.println("Dices is shaking....");
                int dice_Sum = throwDice();
                move(dice_Sum, remainingPlayers.get(j));
                System.out.println();
                System.out.println("Its new location is : " + remainingPlayers.get(j).getCurrentSquare().getSquareNo());

                if(remainingPlayers.get(j).getCurrentSquare() instanceof EarnSquare)
                    System.out.println("This square is earning square and its earning amount is : " + ((EarnSquare) remainingPlayers.get(j).getCurrentSquare()).getEarnings());
                else if (remainingPlayers.get(j).getCurrentSquare() instanceof LossSquare)
                    System.out.println("This square is loss square and its loss amount is : "+((LossSquare) remainingPlayers.get(j).getCurrentSquare()).getTax());
                setBalance(remainingPlayers.get(j));
            }
            sorting_objects_to_balance(remainingPlayers);
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("End of the cycle");
            for (int i = 0; i < remainingPlayers.size(); i++) {
                System.out.println("Player " + remainingPlayers.get(i).getName() + " has balance of  " + remainingPlayers.get(i).getCurrentBalance()
                        +" , its location is " + remainingPlayers.get(i).getCurrentSquare().getSquareNo());
            }
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

            counter--;
        }

    }
    private void move(int moveNum,Player player) throws IOException {

        int newLocation;
        if(moveNum + player.getCurrentSquare().getSquareNo() >= props.getNumberOfSquare()){//touru tamamlar ise
            player.setCurrentBalance(player.getCurrentBalance() + props.getMoneyGivenPerTour());
            newLocation= player.getCurrentSquare().getSquareNo() + moveNum - props.getNumberOfSquare();
            player.setCurrentSquare(board.squares[newLocation]);
        }
        else {//move only
            newLocation = player.getCurrentSquare().getSquareNo() + moveNum ;
            player.setCurrentSquare(board.squares[newLocation]);
        }
    }
    private void setBalance(Player player){
        int amount;
        if(player.getCurrentSquare() instanceof LossSquare){
            if (((LossSquare) player.getCurrentSquare()).getTax() >= player.getCurrentBalance()){
                amount = player.getCurrentBalance();
                player.setCurrentBalance(0);
                System.out.println("Oops!! " + " " + player.getName()+ " " + "went bankrupt!!") ;
                remainingPlayers.remove(player);
                bank.setTotalCash(bank.getTotalCash() + amount);
            }
            else {
                amount=((LossSquare) player.getCurrentSquare()).getTax();
                player.setCurrentBalance(player.getCurrentBalance()-amount);
                bank.setTotalCash(bank.getTotalCash()+amount);
                System.out.println("Players new balance is : "+ player.getCurrentBalance());
            }
        }
        else if(player.getCurrentSquare() instanceof EarnSquare){
            amount = player.getCurrentBalance() + ((EarnSquare) player.getCurrentSquare()).getEarnings();
            player.setCurrentBalance(amount);
            System.out.println("Players new balance is : "+ player.getCurrentBalance());

        }
    }

    private boolean controlFinish(){
        if(counter==0) {
            System.out.println("The game is over ");
            for (int i = 0; i <remainingPlayers.size(); i++) {
                System.out.print("Player " + remainingPlayers.get(i).getName() + " has current balance : "+ remainingPlayers.get(i).getCurrentBalance());
                System.out.println(" and its location is : " + remainingPlayers.get(i).getCurrentSquare().getSquareNo());
            }
            return false;
        }
        else{
            return true;
        }
    }

    private void createPlayers() throws IOException {

        Scanner input = new Scanner(System.in);//take number of players
        Player player;
        for (int i = 1; i <= props.getNumberOfPlayer(); i++) {

            System.out.println("Please enter name of "+ i +"'th simulated player : ");
            player = new Player(input.next());

            player.setCurrentBalance(props.getMoneyGivenBeginningOfGame());
            player.setCurrentSquare(board.squares[0]); //each user start from 0

            System.out.println(player.getName() + " is shaking dices... ");
            player.setDiceSum(dice.getSumOfDice());
            remainingPlayers.add(player);
            players.add(player);
        }
    }

    private void determinePlayingOrder(){
        sorting_objects(remainingPlayers);
        for (int j = 0; j < remainingPlayers.size(); j++) {
            remainingPlayers.get(j).setTurnCounter(j);
            System.out.println(remainingPlayers.get(j).getName() + " " + remainingPlayers.get(j).getDiceSum());
        }
    }
    private void sorting_objects(ArrayList<Player> list) {
        Collections.sort(list, new Comparator<Player>() {
            @Override
            public int compare(Player z1, Player z2) {
                if (z1.getDiceSum() > z2.getDiceSum())
                    return -1;
                if (z1.getDiceSum() < z2.getDiceSum())
                    return 1;
                return 0;
            }
        });
    }
    private void sorting_objects_to_balance(ArrayList<Player> list) {
        Collections.sort(list, new Comparator<Player>() {
            @Override
            public int compare(Player z1, Player z2) {
                if (z1.getCurrentBalance()> z2.getCurrentBalance())
                    return -1;
                if (z1.getCurrentBalance() < z2.getCurrentBalance())
                    return 1;
                return 0;
            }
        });
    }
    private int throwDice(){
        int diceSum = dice.getSumOfDice();
        return diceSum;
    }

}


