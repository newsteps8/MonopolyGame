import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class Board {

    private GameProperties props = new GameProperties();
    private int numberOfSquare;

    Square [] squares = new  Square[props.getNumberOfSquare()];


    public Board() throws IOException {
        this.numberOfSquare = props.getNumberOfSquare();
        createSquares(props.getLossSquareAmount(),props.getEarnSquareAmount());
    }



    public void createSquares(int lossSquares,int earnSquares) throws IOException {

        int min = Math.min(lossSquares, earnSquares);

            for (int i = 0; i < min * 2; i += 2) {
                Square square;
                square = new LossSquare(props.getLossSquareTax());
                square.setSquareNo(i);
                squares[i] = square;
            }

            for (int i = 1; i <=  min * 2; i += 2) {
                Square square;
                square = new EarnSquare(props.getEarnSquareEarning());
                square.setSquareNo(i);
                squares[i] = square;
            }


        if(lossSquares - earnSquares > 0 ){
            int diff = lossSquares -earnSquares;
            Square square ;
            square = new LossSquare(props.getLossSquareTax());
            for (int i = props.getNumberOfSquare() - diff; i < props.getNumberOfSquare(); i++) {
                square.setSquareNo(i);
                squares[i] = square;
            }

        }

        else if(earnSquares - lossSquares > 0){
            int diff = earnSquares -lossSquares ;
            Square square ;
            square = new EarnSquare(props.getLossSquareTax());
            for (int i = props.getNumberOfSquare() -diff; i < props.getNumberOfSquare(); i++) {
                square.setSquareNo(i);
                squares[i] = square;
            }
        }

    }



    public int getNumberOfSquare() {
        return numberOfSquare;
    }

    public void setNumberOfSquare(int numberOfSquare) {
        this.numberOfSquare = numberOfSquare;
    }
}
