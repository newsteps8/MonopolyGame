import java.io.IOException;

public class cse3063f19p1_bgokmen_fcabuk {

    public static void main(String[] args) throws IOException {
        MonopolyGame monopolyGame = new MonopolyGame();
        monopolyGame.play();

    }

}

