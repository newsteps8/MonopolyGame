import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;
import java.util.*;
import java.io.*;

public class GameProperties {

    private FileReader reader=new FileReader("game.properties");
    private Properties p=new Properties();

    public GameProperties() throws FileNotFoundException {
    }

    public int getNumberOfPlayer() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("numberOfPlayer"));
    }
    public int getNumberOfSquare() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("numberOfSquares"));
    }

    public int getMoneyGivenBeginningOfGame() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("moneyGivenBeginningOfGame"));
    }

    public int getMoneyGivenPerTour() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("moneyGivenPerTour"));
    }
    public int getLossSquareTax() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("lossSquareTax"));
    }

    public int getEarnSquareEarning() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("earnSquareEarning"));
    }
    public int getLossSquareAmount() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("lossSquareAmount"));
    }
    public int getEarnSquareAmount() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("earnSquareAmount"));
    }
    public int getCycleCount() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("cycleCount"));
    }
    public int getCashInBank() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("cashInBank"));
    }

}
