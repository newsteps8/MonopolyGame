import java.util.ArrayList;

public class Dice {
    private int sumOfDice;

    public Dice(){
    }

    public int getSumOfDice(){

        int dice1 = ((int) (Math.random() * 5) + 1);
        int dice2 = ((int) (Math.random() * 5) + 1);
        this.sumOfDice = dice1 + dice2;
        System.out.println("\"" + dice1 + " , " + dice2 + "\"");
        return sumOfDice;
    }
}