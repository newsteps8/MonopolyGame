
public class EarnSquare extends Square {

    private Player owner;
    private int earnings;

    public EarnSquare(int earnings){
        super();
        owner=super.getOwner();
        this.earnings=earnings;
    }

    public int getEarnings() {
        return earnings;
    }

    public void setEarnings(int earnings) {
        this.earnings = earnings;
    }

    @Override
    public Player getOwner() {
        return owner;
    }

    @Override
    public void setOwner(Player owner) {
        this.owner = owner;
    }


}
