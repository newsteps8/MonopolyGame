public class LossSquare extends Square {
    private int tax;
    private Player owner;

    public LossSquare(int tax){
        owner=super.getOwner();
        this.tax=tax;
    }

    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    @Override
    public Player getOwner() {
        return owner;
    }

    @Override
    public void setOwner(Player owner) {
        this.owner = owner;
    }
}
