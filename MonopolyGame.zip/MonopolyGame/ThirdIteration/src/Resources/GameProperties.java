package Resources;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;
import java.io.*;

public class GameProperties {//This class use for get the game properties

    private FileReader reader=new FileReader("src/Resources/game.properties");
    private Properties p=new Properties();

    public GameProperties() throws FileNotFoundException {
    }

    public int getNumberOfPlayer() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("numberOfPlayer"));
    }
    public int getNumberOfSquare() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("numberOfSquare"));
    }

    public int getMoneyGivenBeginningOfGame() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("moneyGivenBeginningOfGame"));
    }

    public int getMoneyGivenPerTour() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("moneyGivenPerTour"));
    }
    public int getLossSquareTax() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("lossSquareTax"));
    }
    public int getCycleCount() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("cycleCount"));
    }
    public int getCashInBank() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("cashInBank"));
    }

    public int getWaterTax() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("waterTax"));
    }

    public int getElectricTax() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("electricTax"));
    }
    public int homeSalePrice() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("homeSalePrice"));
    }
    public int homeRentAmount() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("homeRentAmount"));
    }
    public int hotelSalePrice() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("hotelSalePrice"));
    }
    public int hotelRentAmount() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("hotelRentAmount"));
    }
    public int mallSalePrice() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("mallSalePrice"));
    }
    public int mallRentAmount() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("mallRentAmount"));
    }
    public int skyscrapperSalePrice() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("skyscrapperSalePrice"));
    }
    public int skyscrapperRentAmount() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("skyscrapperRentAmount"));
    }
    public int purchaseControlKey() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("purchaseControlKey"));
    }

}
