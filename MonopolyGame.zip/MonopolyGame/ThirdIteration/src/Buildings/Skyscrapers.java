package Buildings;

public class Skyscrapers extends BuildingsForSale {

    public Skyscrapers(int purchasePrice, int rentalFee) {
        super(purchasePrice, rentalFee,"Skyscraper");
    }
}
