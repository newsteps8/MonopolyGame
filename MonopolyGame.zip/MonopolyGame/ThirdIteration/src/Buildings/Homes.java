package Buildings;

public class Homes extends BuildingsForSale {

    public Homes(int purchasePrice, int rentalFee) {
        super(purchasePrice, rentalFee,"Home");
    }
}



