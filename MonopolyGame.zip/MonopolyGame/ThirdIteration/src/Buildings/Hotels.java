package Buildings;


public class Hotels extends BuildingsForSale{

    public Hotels(int purchasePrice, int rentalFee) {
        super(purchasePrice, rentalFee,"Hotel");
    }
}
