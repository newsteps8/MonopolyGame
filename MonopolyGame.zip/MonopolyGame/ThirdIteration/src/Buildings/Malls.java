package Buildings;

public class Malls extends BuildingsForSale{

    public Malls(int purchasePrice, int rentalFee) {
        super(purchasePrice, rentalFee,"Mall");
    }
}

