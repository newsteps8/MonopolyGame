package Buildings;

import src.Player;

public class BuildingsForSale {

    private String name;
    private int purchasePrice;
    private int rentalFee;
    private Player owner;

    public  BuildingsForSale (int purchasePrice,int rentalFee,String name){
        this.purchasePrice=purchasePrice;
        this.rentalFee=rentalFee;
        this.name = name;
    }

    public int getRentalFee() {
        return rentalFee;
    }

    public void setRentalFee(int rentalFee) {
        this.rentalFee = rentalFee;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}


