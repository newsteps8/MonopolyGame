package Squares;
import java.util.ArrayList;

public abstract class Square {

    private int squareNo;
    private String name;
    public ArrayList<Object> buildings = new ArrayList<>();

    protected Square(){

    }
    public int getSquareNo() {
        return squareNo;
    }

    public void setSquareNo(int squareNo) {
        this.squareNo = squareNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
