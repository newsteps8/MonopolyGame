package Squares;

import src.Purchasable;

public class Place extends Purchasable {
    private String color;

    public Place(String name, int purchasePrice, int rentalFee,String color)
    {

        super(name,purchasePrice,rentalFee);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
