package Squares;
import src.Purchasable;
public class Avenue extends Purchasable {

    public Avenue(String name, int purchasePrice, int rentalFee) {
        super(name,purchasePrice,rentalFee);

    }
}
