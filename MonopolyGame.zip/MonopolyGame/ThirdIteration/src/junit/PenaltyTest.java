package junit;

import Cards.Penalty;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PenaltyTest {

    @Test
    void payTwenty() {
        Penalty tester = new Penalty();
        assertEquals(20,tester.payTwenty());
    }

    @Test
    void payFifty() {
        Penalty tester = new Penalty();
        assertEquals(50,tester.payFifty());
    }

    @Test
    void payHundred() {
        Penalty tester = new Penalty();
        assertEquals(100,tester.payHundred());
    }

    @Test
    void getJailIndex() {
        Penalty tester = new Penalty();
        assertEquals(10,tester.getJailIndex());
    }
}