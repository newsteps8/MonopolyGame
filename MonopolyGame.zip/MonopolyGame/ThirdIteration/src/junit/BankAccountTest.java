package junit;

import Squares.Place;
import org.junit.jupiter.api.Test;
import src.BankAccount;
import src.Player;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class BankAccountTest {


    @Test
    void getTotalCash() throws IOException {
        BankAccount tester = new BankAccount();
        tester.setTotalCash(50);
        assertEquals(50,tester.getTotalCash());
    }


    @Test
    void setTotalCash() throws IOException {
        BankAccount tester = new BankAccount();
        tester.setTotalCash(20);
        assertEquals(20,tester.getTotalCash());
    }
}