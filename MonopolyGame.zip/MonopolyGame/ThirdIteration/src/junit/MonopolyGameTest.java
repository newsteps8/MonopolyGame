package junit;

import Squares.ElectricTax;
import Squares.Place;
import Squares.Square;
import org.junit.jupiter.api.Test;
import src.MonopolyGame;
import src.Player;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class MonopolyGameTest {
    Player player = new Player("test1");
    ElectricTax square = new ElectricTax("electric tax",200);

    private Map<Integer, String> purpleColor = new LinkedHashMap<>();
    Square purchaseSquare = new Place("Yerebatan Sarnıcı",100,50,"purple");
    MonopolyGame game = new MonopolyGame();

    MonopolyGameTest() throws IOException {
    }

    @Test
    void controlBankrupt() { //control user bankrupt or not
        boolean controlbankrupt = false;
        Player player = new Player("test1");
        player.setCurrentBalance(player.getCurrentBalance() - ((ElectricTax) square).getTax());
        if(player.getCurrentBalance() < 0){
            controlbankrupt = true;
        }
        assertTrue(controlbankrupt);
    }

    @Test
    void  controlUserCanBuild(){
        purpleColor.put(15,"Ferihan");
        purpleColor.put(14,"Ferihan");
        purpleColor.put(12,"Ferihan");
        assertTrue(game.arePlayerHaveAllColor(purpleColor,14,player));
    }

}