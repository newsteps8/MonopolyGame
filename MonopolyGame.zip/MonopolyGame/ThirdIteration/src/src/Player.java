package src;

import Squares.Square;

public class Player {

    //This is player class in this class players features are specified.

    private String name;
    private int currentBalance =0;
    private int cycleCounter = 0;//Cycle counter of game
    private int turnCounter; //The turn place in game
    private int diceSum =0;
    private Square currentSquare;
    private int jailCounter=0; //specify if it is in jail or not
    private int currentHomes = 0;
    private int currentHotels = 0;
    private int currentMalls = 0;
    private int currentSkyscrapers = 0;


    public Player(String name){
        this.name=name;
    }

    int getTurnCounter() {
        return turnCounter;
    }

    void setTurnCounter(int turnCounter) {
        this.turnCounter = turnCounter;
    }

    public int getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(int currentBalance){
        this.currentBalance = currentBalance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCycleCounter() {
        return cycleCounter;
    }

    public void setCycleCounter(int cycleCounter) {
        this.cycleCounter = cycleCounter;
    }

    int getDiceSum() {
        return diceSum;
    }

    void setDiceSum(int diceSum) {
        this.diceSum = diceSum;
    }

    Square getCurrentSquare() {
        return currentSquare;
    }

    void setCurrentSquare(Square currentSquare) {
        this.currentSquare = currentSquare;
    }

    int getJailCounter() {
        return jailCounter;
    }

    void setJailCounter(int jailCounter) {
        this.jailCounter = jailCounter;
    }

    int getCurrentHomes() {
        return currentHomes;
    }

    void setCurrentHomes(int currentHomes){
        this.currentHomes += currentHomes;
    }

    int getCurrentHotels() {
        return currentHotels;
    }

    void setCurrentHotels(int currentHotels){
        this.currentHotels += currentHotels;
    }

    int getCurrentMalls() {
        return currentMalls;
    }

    void setCurrentMalls(int currentMalls){
        this.currentMalls += currentMalls;
    }

    int getCurrentSkyscrapers() {
        return currentSkyscrapers;
    }

    void setCurrentSkyscrapers(int currentSkyscrapers){
        this.currentSkyscrapers += currentSkyscrapers;
    }

}
