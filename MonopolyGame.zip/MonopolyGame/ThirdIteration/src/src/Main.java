package src;/*
This the monopoly game project for Object-Oriented Programming Lesson
Büşra Gökmen - 150116027
Ferihan Çabuk - 150116059
 */

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        MonopolyGame monopolyGame = new MonopolyGame();
        monopolyGame.play();

    }

}
