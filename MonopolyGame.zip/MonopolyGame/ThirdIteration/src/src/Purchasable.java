package src;

import Squares.Square;

public class Purchasable extends Square {//This class represent the purchasable squares
                                        //If user comes purchasable square and if its balance are enough to buy
                                        //It can purchase the square , it became owner of square

    private String name;
    private int purchasePrice;
    private int rentalFee;
    private Player owner;


    public Purchasable(String name,int purchasePrice,int rentalFee){
        this.name=name;
        this.purchasePrice=purchasePrice;
        this.rentalFee=rentalFee;
    }

    public int getRentalFee() {
        return rentalFee;
    }

    public void setRentalFee(int rentalFee) {
        this.rentalFee = rentalFee;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

}
