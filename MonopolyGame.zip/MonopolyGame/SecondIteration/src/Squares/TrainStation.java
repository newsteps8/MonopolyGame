package Squares;

import src.Purchasable;

public class TrainStation extends Purchasable {
    public TrainStation(String name, int purchasePrice, int rentalFee) {
        super(name, purchasePrice, rentalFee);
    }
}
