package Squares;

import src.Player;
import src.Unpurchasable;

public class ChestSquare extends Unpurchasable {

    private Player owner;
    private int chest;

    public ChestSquare(String name,int chest){
        super(name);
        this.chest=chest;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }

    public int getChest() {
        return chest;
    }

    public void setChest(int chest) {
        this.chest = chest;
    }
}
