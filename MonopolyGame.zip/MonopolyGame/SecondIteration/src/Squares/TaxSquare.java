package Squares;

import src.Player;
import src.Unpurchasable;

public class TaxSquare extends Unpurchasable {
    private int tax;
    private Player owner;

    public TaxSquare(String name, int tax) {
        super(name, tax);
    }


    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
    }
}
