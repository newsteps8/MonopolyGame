package Squares;

import src.Unpurchasable;

public class ElectricTax extends Unpurchasable {
    public ElectricTax(String name ,int tax) {
        super(name,tax);
    }
}
