package Squares;

import src.Purchasable;

public class Place extends Purchasable {

    public Place(String name, int purchasePrice, int rentalFee)
    {
        super(name,purchasePrice,rentalFee);
    }
}
