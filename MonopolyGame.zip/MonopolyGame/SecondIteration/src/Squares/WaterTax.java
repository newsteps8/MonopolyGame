package Squares;

import src.Unpurchasable;

public class WaterTax extends Unpurchasable {
    public WaterTax(String name, int tax) {
        super(name, tax);
    }

}
