package Squares;

import Resources.GameProperties;

import java.io.FileNotFoundException;
import java.io.IOException;

public class StartSquare extends Square {
    private int fee;
    private String name = "Start square";

    public StartSquare(int fee) throws IOException {
        this.fee = fee;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}
