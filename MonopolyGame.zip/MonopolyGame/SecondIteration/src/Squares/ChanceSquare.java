package Squares;
import src.Unpurchasable;

public class ChanceSquare extends Unpurchasable {

    public ChanceSquare(String name){
        super(name);
    }
}
