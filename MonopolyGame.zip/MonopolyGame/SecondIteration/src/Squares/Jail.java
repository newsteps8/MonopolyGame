package Squares;

import src.Unpurchasable;

public class Jail extends Unpurchasable {
    public Jail(String name) {
        super(name);
    }
    //go to 20.th square
    //

}
