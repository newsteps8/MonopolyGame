package Resources;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;
import java.io.*;

public class GameProperties {//This class use for get the game properties

    private FileReader reader=new FileReader("src/Resources/game.properties");
    private Properties p=new Properties();

    public GameProperties() throws FileNotFoundException {
    }

    public int getNumberOfPlayer() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("numberOfPlayer"));
    }
    public int getNumberOfSquare() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("numberOfSquare"));
    }

    public int getMoneyGivenBeginningOfGame() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("moneyGivenBeginningOfGame"));
    }

    public int getMoneyGivenPerTour() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("moneyGivenPerTour"));
    }
    public int getLossSquareTax() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("lossSquareTax"));
    }
    public int getCycleCount() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("cycleCount"));
    }
    public int getCashInBank() throws IOException {
        p.load(reader);
        return Integer.parseInt(p.getProperty("cashInBank"));
    }

    public int getWaterTax() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("waterTax"));
    }

    public int getElectricTax() throws IOException{
        p.load(reader);
        return Integer.parseInt(p.getProperty("electricTax"));
    }

}
