package src;

import Squares.*;

public class Unpurchasable extends Square {

    /*
    These squares do not bought , they are belong to the public.
     */

    private String name;
    private int tax;


    public Unpurchasable(String name,int tax){
        this.name=name;
        this.tax=tax;
    }
    public Unpurchasable(String name){
        this.name=name;
    }

    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}
