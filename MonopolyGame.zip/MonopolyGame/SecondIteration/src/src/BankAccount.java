package src;

import Resources.GameProperties;

import java.io.IOException;

public class BankAccount {
    /*
    This class is bank of the monopoly game
     */

    private int totalCash;
    GameProperties prop = new GameProperties();

    public BankAccount() throws IOException {
        this.totalCash = prop.getCashInBank();
    }

    public int getTotalCash() {
        return totalCash;
    }

    public void setTotalCash(int totalCash) {
        this.totalCash = totalCash;
    }
}


