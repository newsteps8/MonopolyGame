package src;

import Resources.GameProperties;
import Cards.*;
import Squares.*;

import java.io.IOException;
import java.util.*;

public class MonopolyGame {

    public MonopolyGame() throws IOException {
    }
    private ArrayList<Cards> cards= new ArrayList<>();//Chance cards arraylist
    private BankAccount bank = new BankAccount(); //Bank Account
    private Dice dice = new Dice();
    private ArrayList<Player> remainingPlayers = new ArrayList<>();//The players who do not bankrupt
    private ArrayList<Player> players = new ArrayList<>();
    private Board board = new Board();

    private GameProperties props =new GameProperties() ;//Game constants
    private int counter = props.getCycleCount();//how many tour game continue
    private int control,key = 0;
    private Random randomGenerator = new Random();
    private boolean anyBankruptOccur = false;

    public void play() throws IOException {

        createPlayers();
        createCards();
        determinePlayingOrder();
        while(controlFinish()) {//till the game ends...
            for (int j = 0; j < remainingPlayers.size(); j++) { //one cycle
                if(!controlFinish()){
                    break;
                }
                if(remainingPlayers.get(j).getJailCounter() > 0){//If player is in jail it can not take action
                    remainingPlayers.get(j).setJailCounter(remainingPlayers.get(j).getJailCounter()-1);
                }
                else if(remainingPlayers.get(j).getJailCounter() == 0) {//Else continue

                    System.out.println("-----------------------------------------------------------------------------------------");
                    System.out.println("Cycle counter is : " + (props.getCycleCount() - counter + 1));
                    System.out.println("Turn is player: " + remainingPlayers.get(j).getName());
                    System.out.println("Its turn counter is: " + (remainingPlayers.get(j).getTurnCounter() + 1));
                    System.out.println("Its current location is: " + remainingPlayers.get(j).getCurrentSquare().getSquareNo());
                    System.out.println("Name of squares: " + remainingPlayers.get(j).getCurrentSquare().getName());
                    System.out.println("Dices is shaking....");
                    int dice_Sum ;
                    dice_Sum = throwDice();
                    key = dice_Sum;
                    if (dice.getControlDiceSameness()) {//control player throw double dice
                        Player player = remainingPlayers.get(j);
                        move(dice_Sum, remainingPlayers.get(j));
                        System.out.println();
                        System.out.println("Its new location is : " + remainingPlayers.get(j).getCurrentSquare().getSquareNo());
                        takeActionAccordingToSquare(remainingPlayers.get(j), remainingPlayers.get(j).getCurrentSquare());
                        control++;
                        if(!remainingPlayers.contains(player)){//If player bankrupt it leave from the game
                            break;
                        }
                        if(control ==1  &&  !(remainingPlayers.get(j).getCurrentSquare() instanceof Jail)){
                            System.out.println("One more time throw!!");
                            dice_Sum = throwDice();
                            key = dice_Sum;
                            move(dice_Sum, remainingPlayers.get(j));
                            takeActionAccordingToSquare(remainingPlayers.get(j),remainingPlayers.get(j).getCurrentSquare());
                        }
                    }
                    else{ //Player throw different dice
                        key = dice_Sum;
                        move(dice_Sum, remainingPlayers.get(j));
                        System.out.println();
                        System.out.println("Its new location is : " + remainingPlayers.get(j).getCurrentSquare().getSquareNo());
                        takeActionAccordingToSquare(remainingPlayers.get(j), remainingPlayers.get(j).getCurrentSquare());
                    }
                    control = 0;


                }

                if(anyBankruptOccur){
                    j--;
                    anyBankruptOccur = false;
                }
            }

            if(remainingPlayers.size() > 1) {//Every end of the cycle
                sortingObjectsToBalance(remainingPlayers);
                System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                System.out.println("End of the cycle");
                for (int i = 0; i < remainingPlayers.size(); i++) {
                    System.out.println("Player " + remainingPlayers.get(i).getName() + " has balance of  " + remainingPlayers.get(i).getCurrentBalance()
                            + " , its location is " + remainingPlayers.get(i).getCurrentSquare().getSquareNo());
                }
                System.out.println("Bank total cash is " + bank.getTotalCash()+" dolar.");
                System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                counter--;
            }
        }

    }

    private void takeActionAccordingToSquare(Player player,Square square){//Take action according to square type
        Scanner sc = new Scanner(System.in);
        if(square instanceof Avenue){
            if(key>=4) {
                System.out.println("This is " + square.getName() + "it is " +
                        ((Avenue) square).getPurchasePrice() +
                        " dolar \nDo you want to buy it ? if yes enter 1 no enter 2:");
                int input = sc.nextInt();
                if (input == 1) {//If user want to buy
                    if (player.getCurrentBalance() > ((Avenue) square).getPurchasePrice()) {
                        ((Avenue) square).setOwner(player);
                        player.setCurrentBalance(player.getCurrentBalance() - ((Avenue) square).getPurchasePrice());
                        bank.setTotalCash(((Avenue) square).getPurchasePrice()+bank.getTotalCash());
                    } else {
                        System.out.println("Your balance is not enough so go on");
                    }
                }
            }
            else{
                System.out.println("This square is purchasable square but your dice number does not bigger than 8 :( So you dont have any action");
            }
            System.out.println("Player "+ player.getName() +"'s balance is : " + player.getCurrentBalance());
        }
        else if(square instanceof ChanceSquare){
            System.out.println("This is chance square... Your cards is selecting....");
            cardsGenerator(player);
            controlBankrupt(player);
        }
        else if(square instanceof  ChestSquare){
            System.out.println("This is" + square.getName() +"\nYou earn "+ ((ChestSquare) square).getChest() + " " +" dolar !");
            player.setCurrentBalance(player.getCurrentBalance()+((ChestSquare) square).getChest());
            bank.setTotalCash(bank.getTotalCash()-((ChestSquare) square).getChest());

        }
        else if(square instanceof ElectricTax){
            System.out.println("This location is "+" "+ square.getName()+" "+ " .You must pay "+" "+((ElectricTax) square).getTax()+" "+ " electric tax !");
            player.setCurrentBalance(player.getCurrentBalance()-((ElectricTax) square).getTax());
            bank.setTotalCash(bank.getTotalCash() + ((ElectricTax) square).getTax());
            controlBankrupt(player);

        }
        else if(square instanceof Jail){
            player.setJailCounter(1);
            System.out.println("You are in Jail and you must wait for one tour!!");
        }
        else if(square instanceof Place){
            if(key>=8){
                System.out.println("This is "+ square.getName() + " it is " +
                        ((Place) square).getPurchasePrice() +
                        "tl \nDo you want to buy it ? if yes enter 1 no enter 2:");
                int input = sc.nextInt();
                if(input == 1){
                    if(player.getCurrentBalance()>((Place) square).getPurchasePrice()) {
                        ((Place) square).setOwner(player);
                        player.setCurrentBalance(player.getCurrentBalance()-((Place) square).getPurchasePrice());
                    }
                    else {
                        System.out.println("Your balance is not enough so go on");
                    }
                }
            }
            else{
                System.out.println("src.Dice number must be bigger than 8 so you dont have any action");
            }
        }
        else if(square instanceof StartSquare){
        }
        else if(square instanceof TrainStation){
            if(key>=8) {
                System.out.println("This is " + square.getName() + "it is " +
                        ((TrainStation) square).getPurchasePrice() +
                        "tl \nDo you want to buy it ? if yes enter 1 no enter 2:");
                int input = sc.nextInt();
                if (input == 1) {
                    if (player.getCurrentBalance() > ((TrainStation) square).getPurchasePrice()) {
                        ((TrainStation) square).setOwner(player);
                        player.setCurrentBalance(player.getCurrentBalance() - ((TrainStation) square).getPurchasePrice());
                        bank.setTotalCash(bank.getTotalCash()+ ((TrainStation) square).getPurchasePrice());
                    } else {
                        System.out.println("Your balance is not enough!!");
                    }
                }
            }
            else{
                System.out.println("src.Dice number must be bigger than 8 so you dont have any action");
            }
        }
        else if (square instanceof WaterTax){
            System.out.println("This location is "+" "+ square.getName()+" "+ " .You must pay "+ ((WaterTax) square).getTax()+" " + "water tax !");
            player.setCurrentBalance(player.getCurrentBalance()-((WaterTax) square).getTax());
            bank.setTotalCash(bank.getTotalCash() + ((WaterTax) square).getTax());
            controlBankrupt(player);
        }
    }

    private void move(int moveNum, Player player) throws IOException {//Player moves sum of dice next square
        int newLocation;
        if(moveNum + player.getCurrentSquare().getSquareNo() >= props.getNumberOfSquare()){
            //When player complete the tour it gain money that determined by game constants
            player.setCurrentBalance(player.getCurrentBalance() + props.getMoneyGivenPerTour());
            newLocation = player.getCurrentSquare().getSquareNo() + moveNum - props.getNumberOfSquare();
            player.setCurrentSquare(board.squares.get(newLocation));
            bank.setTotalCash(bank.getTotalCash()-props.getMoneyGivenPerTour());
        }
        else {//move only
            newLocation = player.getCurrentSquare().getSquareNo() + moveNum ;
            player.setCurrentSquare(board.squares.get(newLocation));
        }
    }

    private boolean controlFinish(){//Control the finishes of tour number determined by game constants
        if(counter==0 || remainingPlayers.size() == 1) {
            System.out.println("The game is over ");
            for (int i = 0; i <remainingPlayers.size(); i++) {
                System.out.print("Player " + remainingPlayers.get(i).getName() + " has current balance : "+ remainingPlayers.get(i).getCurrentBalance());
                System.out.println(" and its location is : " + remainingPlayers.get(i).getCurrentSquare().getSquareNo());
            }
            return false;
        }
        else{
            return true;
        }
    }

    private void createPlayers() throws IOException {//Create number of players

        Scanner input = new Scanner(System.in);
        Player player;
        for (int i = 1; i <= props.getNumberOfPlayer(); i++) {

            System.out.println("Please enter name of "+ i +"'th simulated player : ");
            player = new Player(input.next());

            player.setCurrentBalance(props.getMoneyGivenBeginningOfGame());
            player.setCurrentSquare(board.squares.get(0)); //each user start from 0
            System.out.println(player.getName() + " is shaking dices... ");
            player.setDiceSum(dice.getSumOfDice());
            remainingPlayers.add(player);
            players.add(player);
        }
    }

    private void determinePlayingOrder(){
        sortingObjects(remainingPlayers);
        for (int j = 0; j < remainingPlayers.size(); j++) {
            remainingPlayers.get(j).setTurnCounter(j);
            System.out.println(remainingPlayers.get(j).getName() + " " + remainingPlayers.get(j).getDiceSum());
        }
    }
    private void sortingObjects(ArrayList<Player> list) {
        Collections.sort(list, new Comparator<Player>() {
            @Override
            public int compare(Player z1, Player z2) {
                if (z1.getDiceSum() > z2.getDiceSum())
                    return -1;
                if (z1.getDiceSum() < z2.getDiceSum())
                    return 1;
                return 0;
            }
        });
    }
    private void sortingObjectsToBalance(ArrayList<Player> list) {
        Collections.sort(list, new Comparator<Player>() {
            @Override
            public int compare(Player z1, Player z2) {
                if (z1.getCurrentBalance()> z2.getCurrentBalance())
                    return -1;
                if (z1.getCurrentBalance() < z2.getCurrentBalance())
                    return 1;
                return 0;
            }
        });
    }
    private int throwDice(){
        int diceSum = dice.getSumOfDice();
        return diceSum;
    }

    private void createCards() throws IOException {
        for(int i=0; i<5; i++){
            Prize prize = new Prize();
            cards.add(prize);
            Penalty penalty = new Penalty();
            cards.add(penalty);
        }
    }
    private void cardsGenerator(Player player){

        Scanner input = new Scanner(System.in);
        int index = randomGenerator.nextInt(cards.size());
        Collections.shuffle(cards);
        Cards item = cards.get(index);
        int turn = (int)(Math.random() * 5);
        if (item instanceof Prize){
            if (turn==0){
                player.setCurrentBalance(player.getCurrentBalance() + ((Prize) item).getDolarTwenty());
                bank.setTotalCash(bank.getTotalCash()-((Prize) item).getDolarTwenty());
                System.out.println(player.getName() +" "+ ", you win 20 Dolar!!");}
            else if(turn==1){
                player.setCurrentBalance(player.getCurrentBalance()+ ((Prize) item).getDolarFifthy());
                bank.setTotalCash(bank.getTotalCash()-((Prize) item).getDolarFifthy());
                System.out.println(player.getName() +" "+ ", you win 50 Dolar!!");
            }
            else if(turn==2) {
                System.out.println("Who do you want to go to the starting square? Please enter player name : ");
                String who = input.nextLine();
                for(int i=0; i<remainingPlayers.size(); i++){
                    if((remainingPlayers.get(i).getName()).equals(who))
                        remainingPlayers.get(i).setCurrentSquare(board.squares.get(0));}
            }
            else if(turn == 3) {
                System.out.println("Hey"+" "+player.getName()+" "+ "who do you want to go to jail? Please enter player name : ");
                String who = input.nextLine();
                for (int i = 0; i < remainingPlayers.size(); i++) {
                    if ((remainingPlayers.get(i).getName()).equals(who))
                        remainingPlayers.get(i).setCurrentSquare(board.squares.get((((Prize) item).getJailIndex())));
                        remainingPlayers.get(i).setJailCounter(1);
                }
            }
            else if (turn==4 ){
                player.setCurrentBalance(player.getCurrentBalance()+((Prize) item).getDolarHundred());
                System.out.println(player.getName() +" "+ ",you win 100 Dolar!!");
                bank.setTotalCash(bank.getTotalCash()-100);
            }
        }

        else if(item instanceof Penalty){
            if (turn==0){
                player.setCurrentBalance(player.getCurrentBalance()-((Penalty) item).payTwenty());
                bank.setTotalCash(bank.getTotalCash() + ((Penalty) item).payTwenty() );
                System.out.println(player.getName() +" "+ ",you lost 20 Dolar!!");}
            else if(turn==1){
                player.setCurrentBalance(player.getCurrentBalance()-((Penalty) item).payFifty());
                bank.setTotalCash(bank.getTotalCash() + ((Penalty) item).payFifty() );
                System.out.println(player.getName() +" "+ ",you lost 50 Dolar!!");}
            else if(turn==2) {
                System.out.println("Player "+player.getName()+" you have to go start square!!");
                player.setCurrentSquare(board.squares.get(0));
            }
            else if(turn == 3){
                player.setCurrentSquare(board.squares.get( ((Penalty) item).getJailIndex()));
                System.out.println("Player "+ player.getName()+" "+ " must wait in Jail for one tour!!");
                player.setJailCounter(1);
            }

            else if (turn==4) {
                player.setCurrentBalance(player.getCurrentBalance() - ((Penalty) item).payHundred());
                bank.setTotalCash(bank.getTotalCash() + ((Penalty) item).payHundred() );
                System.out.println(player.getName() +" "+ " ,you lost 100 Dolar!!");
            }
        }
    }

    public void controlBankrupt(Player player){
         if(player.getCurrentBalance() <= 0){
             System.out.println("\n Opps ! Player " + player.getName() + " bankrupt !" );
             player.setCurrentBalance(0);
             System.out.println("Player "+ player.getName() +"'s balance is : " + player.getCurrentBalance());
             remainingPlayers.remove(player);
             anyBankruptOccur = true ;
         }
         else{
             System.out.println("Player "+ player.getName() +"'s balance is : " + player.getCurrentBalance());
         }
         if(remainingPlayers.size() == 1){
             System.out.println("*************************************************");
             System.out.println("*************************************************");
             System.out.println("The winner of the game is Player : " + remainingPlayers.get(0).getName()+ " Congratulations !!!!");
             System.out.println("*************************************************");
             System.out.println("*************************************************");
         }

    }


}


