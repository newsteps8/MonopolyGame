package src;

class Dice {
    //This class is dices in the game , when it created return 2 dice values
    private int dice1 ;
    private int dice2 ;

    int getSumOfDice(){
        dice1 = ((int) (Math.random() * 5) + 1);
        dice2 = ((int) (Math.random() * 5) + 1);
        int sumOfDice = dice1 + dice2;
        System.out.println("\"" + dice1 + " , " + dice2 + "\"");
        return sumOfDice;
    }

    Boolean getControlDiceSameness(){
        return dice1 == dice2;
    }
}