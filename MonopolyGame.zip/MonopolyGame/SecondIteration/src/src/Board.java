package src;

import Resources.GameProperties;
import Squares.*;

import java.io.IOException;
import java.util.ArrayList;

public class Board {

    /*
    In this class all squares in the board is created.
     */

    private GameProperties props = new GameProperties();
    private int numberOfSquare;

    ArrayList<Square> squares = new ArrayList<>();


    Board() throws IOException {
        createSquares();
    }


    private void createSquares() throws IOException {

        createStartSquare();//0
        createWaterTaxSquare();
        createAvenueSquare("Fahrettin Kerim Gökay Avenue",300,50);
        createWaterTaxSquare();
        createAvenueSquare("İstiklal Avenue",100,50);
        createChanceCardSquare();
        createAvenueSquare("Bağdat Avenue ",200,60);
        createElectricTaxSquare();
        createAvenueSquare("Nispetiye Avenue",200,50);
        createWaterTaxSquare();
        createJail();//10
        createChestSquare(550);
        createElectricTaxSquare();
        createTrainStationSquare("Sirkeci",600,50);
        createPlaceSquare("Ayasofya Camii",600,100);
        createChanceCardSquare();//15
        createElectricTaxSquare();
        createPlaceSquare("Topkapı Sarayı",600,50);
        createPlaceSquare("Kız Kulesi",600,50);
        createPlaceSquare("Kapalı Çarşı",600,50);
        createChestSquare(500);//20
        createPlaceSquare("Yerebatan Sarnıcı",600,50);
        createPlaceSquare("Rumeli Hisarı",600,50);
        createTrainStationSquare("Maltepe",600,30);
        createPlaceSquare("Yoros Kalesi",600,50);
        createPlaceSquare("Sultanahmet Camii",600,50);
        createPlaceSquare("Hidiv Kasrı",600,50);
        createPlaceSquare("Küçüksu Kasrı",600,50);
        createPlaceSquare("Galata",600,50);
        createPlaceSquare("Selimiye",550,50);
        createJail();
        createPlaceSquare("Kadıköy",600,40);
        createPlaceSquare("Üsküdar",600,50);
        createTrainStationSquare("Halkalı",500,100);
        createChanceCardSquare();
        createPlaceSquare("Ataşehir",600,50);
        createPlaceSquare("Beşiktaş",600,50);
        createPlaceSquare("Esenler",600,50);
        createPlaceSquare("Çamlıca Tepesi",600,50);
        createPlaceSquare("Ümraniye",600,50);//39

        for (int i = 0; i < squares.size() ; i++) {
            squares.get(i).setSquareNo(i);
        }
    }

    private void createStartSquare() throws IOException {
        int fee = props.getMoneyGivenPerTour();
        Square square = new StartSquare(fee);
        squares.add(square);
    }
    private void createChanceCardSquare(){
        String name="Chance Card";
        Square square = new ChanceSquare(name);
        squares.add(square);
    }
    private void createChestSquare(int chestAmount){
        String name = "Chest Square";
        Square square =new ChestSquare(name,chestAmount);
        squares.add(square);
    }
    private void createJail(){
        String name = "Jail";
        Square square = new Jail(name);
        squares.add(square);
    }
    private void createElectricTaxSquare() throws IOException {
        String name = "Electric Tax";
        Square square = new ElectricTax(name,props.getElectricTax());
        squares.add(square);
    }
    private void createWaterTaxSquare() throws IOException {
        String name = "Water Tax";
        Square square = new WaterTax(name,props.getWaterTax());
        squares.add(square);
    }
    private void createTrainStationSquare(String name, int purchaseAmount, int rentAmount){
        Square square = new TrainStation(name,purchaseAmount,rentAmount);
        squares.add(square);
    }
    private void createAvenueSquare(String name, int purchaseAmount, int rentAmount){
        Square square = new Avenue(name,purchaseAmount,rentAmount);
        squares.add(square);
    }

    private void createPlaceSquare(String name, int purchaseAmount, int rentAmount){
        Square square = new Place(name,purchaseAmount,rentAmount);
        squares.add(square);
    }

    public int getNumberOfSquare() {
        return numberOfSquare;
    }

    public void setNumberOfSquare(int numberOfSquare) {
        this.numberOfSquare = numberOfSquare;
    }

}



