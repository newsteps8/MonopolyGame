package Cards;

public class Cards
{
    Cards(){
    }

}
