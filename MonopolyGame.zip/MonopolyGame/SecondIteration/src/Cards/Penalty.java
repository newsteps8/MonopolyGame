package Cards;

public class Penalty extends Cards
{
    public int payTwenty() {
        return 20;
    }

    public int payFifty() {
        return 50;
    }

    public int payHundred() { return 100; }

    public int getJailIndex() {//jail index
        return 10;
    }

}
