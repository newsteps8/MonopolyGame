package Cards;

public class Prize extends Cards {

    public int getDolarTwenty() {
        return 20;
    }
    public int getDolarFifthy() {
        return 50;
    }
    public int getDolarHundred() {
        return 100;
    }
    public int getJailIndex() { return 10 ; }

}